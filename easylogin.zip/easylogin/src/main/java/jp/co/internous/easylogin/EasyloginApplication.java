package jp.co.internous.easylogin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EasyloginApplication {

	public static void main(String[] args) {
		SpringApplication.run(EasyloginApplication.class, args);
	}

}
